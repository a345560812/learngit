package com.atao.util;

public class MyConstant {
	

	// 发送邮件的邮箱，要与df.properties中的一致
	public static final String MAIL_FROM = "m13245079335@163.com";

	// 域名
	 public static final String DOMAIN_NAME = "http://localhost:8080/";
	 // public static final String DOMAIN_NAME = "http://naivee.me/";

}
